/**
  ******************************************************************************
  * @file    main.c
  * @author  MCD Application Team
  * @brief   this is the main!
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2018 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                             www.st.com/SLA0044
  *
  ******************************************************************************
  */
/*PA10 -> RX
 * PB6 -> TX
 * PB15 -> CS
 * PA0 -> Battery
 * PA4 -> Tore
 */

/* Includes ------------------------------------------------------------------*/
#include "hw.h"
#include "low_power_manager.h"
#include "lora.h"
#include "bsp.h"
#include "timeServer.h"
#include "vcom.h"
#include "version.h"

#include "main.h"
#include "adc.h"
#include "dma.h"
#include "rtc.h"
#include "spi.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private typedef -----------------------------------------------------------*/
#define CapteurON	1
#define CapteurOFF	0
/* Private define ------------------------------------------------------------*/



/*!
 * CAYENNE_LPP is myDevices Application server.
 */
#define CAYENNE_LPP
#define LPP_DATATYPE_DIGITAL_INPUT  0x0
#define LPP_DATATYPE_DIGITAL_OUTPUT 0x1
#define LPP_DATATYPE_HUMIDITY       0x68
#define LPP_DATATYPE_TEMPERATURE    0x67
#define LPP_DATATYPE_BAROMETER      0x73
#define LPP_DATATYPE_CONCENTRATION_PM1  0x5D
#define LPP_DATATYPE_CONCENTRATION_PM25  0x6D
#define LPP_DATATYPE_CONCENTRATION_PM10  0x7D
#define LPP_DATATYPE_POWER_MEASUREMENT  0x69
#define LPP_APP_PORT 99
/*!
 * Defines the application data transmission duty cycle. 5s, value in [ms].
 */
#define APP_TX_DUTYCYCLE                            30000
/*!
 * LoRaWAN Adaptive Data Rate
 * @note Please note that when ADR is enabled the end-device should be static
 */
#define LORAWAN_ADR_STATE LORAWAN_ADR_ON
/*!
 * LoRaWAN Default data Rate Data Rate
 * @note Please note that LORAWAN_DEFAULT_DATA_RATE is used only when ADR is disabled 
 */
#define LORAWAN_DEFAULT_DATA_RATE DR_0
/*!
 * LoRaWAN application port
 * @note do not use 224. It is reserved for certification
 */
#define LORAWAN_APP_PORT                            2
/*!
 * LoRaWAN default endNode class port
 */
#define LORAWAN_DEFAULT_CLASS                       CLASS_C
/*!
 * LoRaWAN default confirm state
 */
#define LORAWAN_DEFAULT_CONFIRM_MSG_STATE           LORAWAN_UNCONFIRMED_MSG
/*!
 * User application data buffer size
 */
#define LORAWAN_APP_DATA_BUFF_SIZE                           64
/*!
 * User application data
 */
static uint8_t AppDataBuff[LORAWAN_APP_DATA_BUFF_SIZE];

/*!
 * User application data structure
 */
//static lora_AppData_t AppData={ AppDataBuff,  0 ,0 };
lora_AppData_t AppData={ AppDataBuff,  0 ,0 };

/* Private macro -------------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/


/* Get the PM (particulate matters) concentration in ug/m3 */
void GetParticule(void);

/*Try to active the PM sensor  */
void GetSensorState(void);

/* Init PM sensor before getting data */
void InitPMSensor(void);

/* Active the PM sensor */
void ParticuleSensorON(void);

/* Deactivates the PM sensor */
void ParticuleSensorOFF(void);

/*Active or deactivate the PM sensor */
void SensorControl(uint8_t EtatCapteur);

/*Decode the request receive by LoRa */
void DecodeRequest(void);

/*Check if all necessary data are collected and call the function */
void CheckBeforeSend(void);

/* call back when LoRa endNode has received a frame*/
static void LORA_RxData( lora_AppData_t *AppData);

/* call back when LoRa endNode has just joined*/
static void LORA_HasJoined( void );

/* call back when LoRa endNode has just switch the class*/
static void LORA_ConfirmClass ( DeviceClass_t Class );

/* call back when server needs endNode to send a frame*/
static void LORA_TxNeeded ( void );

/* LoRa endNode send request*/
static void Send( void* context );

/* start the tx process*/
static void LoraStartTx(TxEventType_t EventType);

/* tx timer callback function*/
static void OnTxTimerEvent( void* context );

/* tx timer callback function*/
static void LoraMacProcessNotify( void );

/* Private variables ---------------------------------------------------------*/
volatile char Watchdog = 0;
volatile uint8_t BatteryValue = 0;
volatile uint8_t DCSensorValue = 0;
char StartADC = 0;
volatile char StartUART = 0;
uint8_t TransmitUART[3];
uint8_t ReceiveUART[16];
uint8_t DataParticule[6];
volatile uint8_t DataErrorSensor= 0x00;
volatile char ParticuleDataReceive = 0;
volatile char SensorStateReceive = 0;
volatile char SensorErrorReceive = 0;
volatile char GetBatteryLevel = 0;
volatile char GetPM = 0;
volatile char BatteryLevelObtain = 0;
volatile char PMObtain = 0;
volatile char BatteryLevelAsked = 0;
volatile char PMAsked = 0;
volatile uint8_t SensorTimerCpt = 0;
char TxReady = 0;
volatile char TestRx = 0;
volatile char Test1 = 0;
volatile char Test2 = 0;
volatile char Retry = 0;
volatile char RetryOK = 0;
volatile int cpt = 0;
volatile char TxProcessing = 0;

enum PSensorState {
	State0, State1, State2
};
volatile enum PSensorState PSensorState = State0;

/* load Main call backs structure*/
static LoRaMainCallback_t LoRaMainCallbacks = { HW_GetUniqueId,
                                                HW_GetRandomSeed,
                                                LORA_RxData,
                                                LORA_HasJoined,
                                                LORA_ConfirmClass,
                                                LORA_TxNeeded,
                                                LoraMacProcessNotify};
LoraFlagStatus LoraMacProcessRequest=LORA_RESET;
LoraFlagStatus AppProcessRequest=LORA_RESET;
/*!
 * Specifies the state of the application LED
 */
//static uint8_t AppLedStateOn = RESET;
                                               
static TimerEvent_t TxTimer;

#ifdef USE_B_L072Z_LRWAN1
/*!
 * Timer to handle the application Tx Led to toggle
 */
static TimerEvent_t TxLedTimer;
static void OnTimerLedEvent( void* context );
#endif
/* !
 *Initialises the Lora Parameters
 */
static  LoRaParam_t LoRaParamInit= {LORAWAN_ADR_STATE,
                                    LORAWAN_DEFAULT_DATA_RATE,  
                                    LORAWAN_PUBLIC_NETWORK};

/* Private functions ---------------------------------------------------------*/

/**
  * @brief  Main program
  * @param  None
  * @retval None
  */
int main( void )
{
  /* STM32 HAL library initialization*/
  HAL_Init();
  
  /* Configure the system clock*/
  SystemClock_Config();
  
  /* Configure the debug mode*/
  DBG_Init();
  
  /* Configure the hardware*/
  HW_Init();
  
  /* USER CODE BEGIN 1 */
  /* Initialize all configured peripherals */
    MX_GPIO_Init();
    MX_DMA_Init();
    MX_ADC_Init();
    MX_TIM6_Init();
    MX_TIM7_Init();
    MX_USART1_UART_Init();


    HAL_TIM_Base_Start_IT(&htim6);
    ParticuleSensorOFF();
  /* USER CODE END 1 */
  
  /*Disable Stand-by mode*/
  LPM_SetOffMode(LPM_APPLI_Id , LPM_Disable );
  
  //PRINTF("VERSION: %X\n\r", VERSION);
  
  /* Configure the Lora Stack*/
  LORA_Init( &LoRaMainCallbacks, &LoRaParamInit);
  
  LORA_Join();

  LoraStartTx( TX_ON_TIMER) ;
  
  while( 1 )
  {
    if (AppProcessRequest==LORA_SET)
    {
      /*reset notification flag*/
      AppProcessRequest=LORA_RESET;


      GetBatteryLevel = 1;
      BatteryLevelAsked = 1;
      GetPM = 1;
      PMAsked = 1;
      InitPMSensor();

    }
	if (LoraMacProcessRequest==LORA_SET)
    {
      /*reset notification flag*/
      LoraMacProcessRequest=LORA_RESET;
      LoRaMacProcess( );
    }
    /*If a flag is set at this point, mcu must not enter low power and must loop*/
    DISABLE_IRQ( );
    
    /* if an interrupt has occurred after DISABLE_IRQ, it is kept pending 
     * and cortex will not enter low power anyway  */
    if ((LoraMacProcessRequest!=LORA_SET) && (AppProcessRequest!=LORA_SET))
    {
#ifndef LOW_POWER_DISABLE
      LPM_EnterLowPower( );
#endif
    }

    ENABLE_IRQ();
    
    /* USER CODE BEGIN 2 */
	if (GetBatteryLevel)
	{
		GetBatteryLevel = 0;
		HAL_ADC_Start(&hadc);
		HAL_ADC_PollForConversion(&hadc, 100);
		BatteryValue = HAL_ADC_GetValue(&hadc);

		HAL_ADC_PollForConversion(&hadc, 100);
		DCSensorValue = HAL_ADC_GetValue(&hadc);

		HAL_ADC_Stop (&hadc);
		BatteryLevelObtain = 1;

		//HAL_ADC_Start_DMA(&hadc, (uint32_t *) adc_buffer, 2);
		//HAL_ADC_Start_IT(&hadc);
	}
	if(GetPM)
	{
		switch (PSensorState) {
				case State0 : {
					if(SensorTimerCpt == 2)
					{
						GetSensorState();
						PSensorState = State1;
						DataErrorSensor = 1;
						SensorStateReceive = 0;
					}
					break;
				}
				case State1 : {
					if(StartUART == 0)
					{
						if(SensorStateReceive)
						{
							SensorStateReceive = 0;
							if(DataErrorSensor%2==0)
							{
								DataErrorSensor = 1;
								HAL_TIM_Base_Stop(&htim7);
								HAL_UART_AbortReceive_IT(&huart1);
								HAL_UART_AbortTransmit_IT(&huart1);
								HAL_TIM_Base_Start(&htim7);
								PSensorState = State2;
								GetParticule();
								RetryOK = 0;
							}
							else
							{
								GetSensorState();
							}
						}
						else if(SensorTimerCpt == 3)
						{
							GetSensorState();
						}
					}
					else if(SensorTimerCpt == 4)
					{
						HAL_TIM_Base_Stop(&htim7);
						HAL_UART_AbortReceive_IT(&huart1);
						HAL_UART_AbortTransmit_IT(&huart1);
						//Get State failed
						HAL_TIM_Base_Start(&htim7);
						GetParticule();
						PSensorState = State2;
						//Test1 = 1;
						//Retry = 1;
					}
					break;
				}
				case State2 : {
					if(SensorTimerCpt == 6)
					{
						HAL_TIM_Base_Stop(&htim7);
						HAL_UART_AbortReceive_IT(&huart1);
						HAL_UART_AbortTransmit_IT(&huart1);
						//transmission failed
						//TxReady = 1;
						ParticuleSensorOFF();
						GetPM = 0;
						PMObtain = 1;
						//Test2 = 1;
					}
					if(StartUART == 0 && ParticuleDataReceive == 1)
					{
						HAL_TIM_Base_Stop(&htim7);
						HAL_UART_AbortReceive_IT(&huart1);
						HAL_UART_AbortTransmit_IT(&huart1);
						//TxReady = 1;
						ParticuleSensorOFF();
						GetPM = 0;
						PMObtain = 1;
					}
					break;
				}
		}
	}
    CheckBeforeSend();

    /* USER CODE END 2 */
  }
}

void GetParticule(void)
{
	HAL_UART_Receive_IT(&huart1, ReceiveUART, 16);
	TransmitUART[0] = 0x81;
	TransmitUART[1] = 0x11;
	TransmitUART[2] = 0x6e;
	StartUART = 1;
	HAL_UART_Transmit_IT(&huart1, TransmitUART,3);
}
void GetSensorState(void)
{
	HAL_UART_Receive_IT(&huart1, ReceiveUART, 4);
	TransmitUART[0] = 0x81;
	TransmitUART[1] = 0x16;
	TransmitUART[2] = 0x69;
	StartUART = 1;
	HAL_UART_Transmit_IT(&huart1, TransmitUART,3);
}

void InitPMSensor(void)
{
    //SensorON then send
    ParticuleSensorON();
    HAL_TIM_Base_Start_IT(&htim7);
    SensorTimerCpt = 0;
    PSensorState = State0;
}

void ParticuleSensorON(void)
{
	SensorControl(CapteurON);
}

void ParticuleSensorOFF(void)
{
	SensorControl(CapteurOFF);
}
void SensorControl(uint8_t EtatCapteur)
{
	if(EtatCapteur == CapteurON)
	{
		HAL_GPIO_WritePin(GPIOB,GPIO_PIN_15, 0);
	}
	else
	{
		HAL_GPIO_WritePin(GPIOB,GPIO_PIN_15, 1);
	}
}

void DecodeRequest(void)
{
	if( AppData.BuffSize == 1 && TxProcessing == 0)
	{
		switch (AppData.Buff[0])
		{
			case 0x0A: //Battery level
			{
				BatteryLevelAsked = 1;
				GetBatteryLevel = 1;
				TxProcessing = 1;
				Test1 = 1;
				break;
			}
			case 0x0B: //PM
			{
				PMAsked = 1;
				GetPM = 1;
				TxProcessing = 1;
				break;
			}
			case 0x79: //Battery and PM
			{
				BatteryLevelAsked = 1;
				PMAsked = 1;
				GetBatteryLevel = 1;
				GetPM = 1;
				TxProcessing = 1;
				Test2 = 1;
				break;
			}
			default:
				break;
		}
	}
}

void CheckBeforeSend(void)
{
	if(BatteryLevelAsked && PMAsked)
	{
		if(BatteryLevelObtain && PMObtain)
		{
			//BatteryLevelAsked = 0;
			//PMAsked = 0;
			//BatteryLevelObtain = 0;
			//PMObtain = 0;
			Send(NULL);
		}
	}
	else if(BatteryLevelAsked)
	{
		if(BatteryLevelObtain)
		{
			BatteryLevelAsked = 0;
			//BatteryLevelObtain = 0;
			Send(NULL);
		}
	}
	else if(PMAsked)
	{
		if(PMObtain)
		{
			PMAsked = 0;
			//PMObtain = 0;
			Send(NULL);
		}
	}

}


/*void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc)
{

  ADCValue1 = HAL_ADC_GetValue(hadc);
  ADCValue = adc_buffer[0];
  BatteryLevelObtain = 1;
  GetBatteryLevel = 0;
  /*if(ADCValue < 160)
  {
	  Watchdog = 1;
  }*/
  //HAL_ADC_Stop_IT(hadc);
  //HAL_ADC_Stop_DMA(hadc);
//}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef * htim)
{
	if ( htim->Instance == TIM6)
	{
		GetBatteryLevel = 1;
		//HAL_ADC_Start_IT(&hadc);
		//HAL_ADC_Start_DMA(&hadc, (uint32_t *) adc_buffer, 2);
	}
	if ( htim->Instance == TIM7)
	{
		SensorTimerCpt++;
	}
}

void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
  if ( huart->Instance == USART1)
    {

    }
  if(huart->Instance == USART2)
  {
	  TxCpltCallback();
  }
}


void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
  if ( huart->Instance == USART1)
  	{
	  StartUART = 0;
	  if(ReceiveUART[0] == 0x81)
	  {
		  if(ReceiveUART[1] == 0x11 || ReceiveUART[1] == 0x12 || ReceiveUART[1] == 0x13 )
		  {
			 ParticuleDataReceive = 1;
			 PMObtain = 1;
			 DataParticule[0] = ReceiveUART[9];
			 DataParticule[1] = ReceiveUART[10];
			 DataParticule[2] = ReceiveUART[11];
			 DataParticule[3] = ReceiveUART[12];
			 DataParticule[4] = ReceiveUART[13];
			 DataParticule[5] = ReceiveUART[14];
		  }
		  else if(ReceiveUART[1] == 0x16)
		  {
			  SensorStateReceive = 1;
			  DataErrorSensor = ReceiveUART[2];
		  }
		  else
		  {
			  SensorErrorReceive = 1;
		  }
	  }
	  else if(ReceiveUART[1] == 0x81)
	  {
		  if(ReceiveUART[2] == 0x11 || ReceiveUART[2] == 0x12 || ReceiveUART[2] == 0x13 )
		  {
			 ParticuleDataReceive = 1;
			 PMObtain = 1;
			 DataParticule[0] = ReceiveUART[10];
			 DataParticule[1] = ReceiveUART[11];
			 DataParticule[2] = ReceiveUART[12];
			 DataParticule[3] = ReceiveUART[13];
			 DataParticule[4] = ReceiveUART[14];
			 DataParticule[5] = ReceiveUART[15];
		  }
		  else if(ReceiveUART[2] == 0x16)
		  {
			  SensorStateReceive = 1;
			  DataErrorSensor = ReceiveUART[3];
		  }
		  else
		  {
			  SensorErrorReceive = 1;
		  }
	  }
  	}
}




void LoraMacProcessNotify(void)
{
  LoraMacProcessRequest=LORA_SET;
}


static void LORA_HasJoined( void )
{
#if( OVER_THE_AIR_ACTIVATION != 0 )
  PRINTF("JOINED\n\r");
#endif
  LORA_RequestClass( LORAWAN_DEFAULT_CLASS );
}

static void Send( void* context )
{
  /* USER CODE BEGIN 3 */
  if ( LORA_JoinStatus () != LORA_SET)
  {
    /*Not joined, try again later*/
    LORA_Join();
    return;
  }
  
  TVL1(PRINTF("SEND REQUEST\n\r");)
#ifndef CAYENNE_LPP
  int32_t latitude, longitude = 0;
  uint16_t altitudeGps = 0;
#endif
  
#ifdef USE_B_L072Z_LRWAN1
  TimerInit( &TxLedTimer, OnTimerLedEvent );
  
  TimerSetValue(  &TxLedTimer, 200);
  
  LED_On( LED_RED1 ) ; 
  
  TimerStart( &TxLedTimer );  
#endif

  //BSP_sensor_Read( &sensor_data );

#ifdef CAYENNE_LPP

  uint32_t i = 0;
  AppData.Port = LPP_APP_PORT;

  if(BatteryLevelObtain && BatteryLevelAsked)
  {
	  BatteryLevelAsked = 0;
	  BatteryLevelObtain = 0;
	  AppData.Buff[i++] = LPP_DATATYPE_POWER_MEASUREMENT;
	  AppData.Buff[i++] = BatteryValue;
  }
  AppData.Buff[i++] = LPP_DATATYPE_POWER_MEASUREMENT;
  AppData.Buff[i++] = BatteryValue;

  if(PMObtain && PMAsked)
  {
	  	PMAsked = 0;
		PMObtain = 0;

		AppData.Buff[i++] = LPP_DATATYPE_CONCENTRATION_PM1;
		AppData.Buff[i++] = DataParticule[0];
		AppData.Buff[i++] = DataParticule[1];

		AppData.Buff[i++] = LPP_DATATYPE_CONCENTRATION_PM25;
		AppData.Buff[i++] = DataParticule[2];
		AppData.Buff[i++] = DataParticule[3];

		AppData.Buff[i++] = LPP_DATATYPE_CONCENTRATION_PM10;
		AppData.Buff[i++] = DataParticule[4];
		AppData.Buff[i++] = DataParticule[5];
  }
  if(TestRx)
  {
	  TestRx = 0;
	  AppData.Buff[i++] = 0xAA;
  }
  if(Test1)
  {
	  Test1 = 0;
	  AppData.Buff[i++] = 0xBB;
  }
  if(Test2)
  {
	  Test2 = 0;
	  AppData.Buff[i++] = 0xCC;
  }
#if defined( REGION_US915 ) || defined ( REGION_AU915 )
  /* The maximum payload size does not allow to send more data for lowest DRs */
#else
  /*AppData.Buff[i++] = cchannel++;
  AppData.Buff[i++] = LPP_DATATYPE_DIGITAL_INPUT;
  AppData.Buff[i++] = 0x00;
  AppData.Buff[i++] = cchannel++;
  AppData.Buff[i++] = LPP_DATATYPE_DIGITAL_INPUT;
  AppData.Buff[i++] = 0x00;*/
#endif  /* REGION_XX915 */
#else  /* not CAYENNE_LPP */

  temperature = ( int16_t )( sensor_data.temperature * 100 );     /* in �C * 100 */
  pressure    = ( uint16_t )( sensor_data.pressure * 100 / 10 );  /* in hPa / 10 */
  humidity    = ( uint16_t )( sensor_data.humidity * 10 );        /* in %*10     */
  latitude = sensor_data.latitude;
  longitude= sensor_data.longitude;
  uint32_t i = 0;

  batteryLevel = HW_GetBatteryLevel( );                     /* 1 (very low) to 254 (fully charged) */

  AppData.Port = LORAWAN_APP_PORT;

#if defined( REGION_US915 ) || defined ( REGION_AU915 )
  AppData.Buff[i++] = AppLedStateOn;
  AppData.Buff[i++] = ( pressure >> 8 ) & 0xFF;
  AppData.Buff[i++] = pressure & 0xFF;
  AppData.Buff[i++] = ( temperature >> 8 ) & 0xFF;
  AppData.Buff[i++] = temperature & 0xFF;
  AppData.Buff[i++] = ( humidity >> 8 ) & 0xFF;
  AppData.Buff[i++] = humidity & 0xFF;
  AppData.Buff[i++] = batteryLevel;
  AppData.Buff[i++] = 0;
  AppData.Buff[i++] = 0;
  AppData.Buff[i++] = 0;
#else  /* not REGION_XX915 */
  AppData.Buff[i++] = AppLedStateOn;
  AppData.Buff[i++] = ( pressure >> 8 ) & 0xFF;
  AppData.Buff[i++] = pressure & 0xFF;
  AppData.Buff[i++] = ( temperature >> 8 ) & 0xFF;
  AppData.Buff[i++] = temperature & 0xFF;
  AppData.Buff[i++] = ( humidity >> 8 ) & 0xFF;
  AppData.Buff[i++] = humidity & 0xFF;
  AppData.Buff[i++] = batteryLevel;
  AppData.Buff[i++] = ( latitude >> 16 ) & 0xFF;
  AppData.Buff[i++] = ( latitude >> 8 ) & 0xFF;
  AppData.Buff[i++] = latitude & 0xFF;
  AppData.Buff[i++] = ( longitude >> 16 ) & 0xFF;
  AppData.Buff[i++] = ( longitude >> 8 ) & 0xFF;
  AppData.Buff[i++] = longitude & 0xFF;
  AppData.Buff[i++] = ( altitudeGps >> 8 ) & 0xFF;
  AppData.Buff[i++] = altitudeGps & 0xFF;
#endif  /* REGION_XX915 */
#endif  /* CAYENNE_LPP */
  AppData.BuffSize = i;
  TxProcessing = 0;
  LORA_send( &AppData, LORAWAN_DEFAULT_CONFIRM_MSG_STATE);
  
  /* USER CODE END 3 */
}


static void LORA_RxData( lora_AppData_t *AppData )
{
  /* USER CODE BEGIN 4 */
  //PRINTF("PACKET RECEIVED ON PORT %d\n\r", AppData->Port);
	DecodeRequest();
	TestRx = 1;
  /* USER CODE END 4 */
}

static void OnTxTimerEvent( void* context )
{
	/*Wait for next tx slot*/
	TimerStart( &TxTimer);
	cpt++;
	if(cpt > 4 && TxProcessing == 0 )
	{
		cpt = 0;
		TxProcessing = 1;
		AppProcessRequest=LORA_SET;
	}

  
}

static void LoraStartTx(TxEventType_t EventType)
{
  if (EventType == TX_ON_TIMER)
  {
    /* send everytime timer elapses */
    TimerInit( &TxTimer, OnTxTimerEvent );
    TimerSetValue( &TxTimer,  APP_TX_DUTYCYCLE); 
    OnTxTimerEvent( NULL );
  }
  else
  {
    /* send everytime button is pushed */
    GPIO_InitTypeDef initStruct={0};
  
    initStruct.Mode =GPIO_MODE_IT_RISING;
    initStruct.Pull = GPIO_PULLUP;
    initStruct.Speed = GPIO_SPEED_HIGH;

    HW_GPIO_Init( USER_BUTTON_GPIO_PORT, USER_BUTTON_PIN, &initStruct );
    HW_GPIO_SetIrq( USER_BUTTON_GPIO_PORT, USER_BUTTON_PIN, 0, Send );
  }
}

static void LORA_ConfirmClass ( DeviceClass_t Class )
{
  PRINTF("switch to class %c done\n\r","ABC"[Class] );

  /*Optionnal*/
  /*informs the server that switch has occurred ASAP*/
  AppData.BuffSize = 0;
  AppData.Port = LORAWAN_APP_PORT;
  
  LORA_send( &AppData, LORAWAN_UNCONFIRMED_MSG);
}

static void LORA_TxNeeded ( void )
{
  AppData.BuffSize = 0;
  AppData.Port = LORAWAN_APP_PORT;
  
  LORA_send( &AppData, LORAWAN_UNCONFIRMED_MSG);
}

#ifdef USE_B_L072Z_LRWAN1
static void OnTimerLedEvent( void* context )
{
  LED_Off( LED_RED1 ) ; 
}
#endif
/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
